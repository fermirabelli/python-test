#file=open("lista-blancos.xml", "r")
file = ET.parse('lista-blancos.xml')
#file = tree.getroot()

site=file.ET.Element("ar.mil.cideso.sitea.blanco.Blanco")
for c in file.findall(".//designacion"):
    dupe = copy.deepcopy(c) #copy <c> node
    b.append(dupe) #insert the new node
print(ET.tostring(file))

#file.write("out.xml")
#file.close()
