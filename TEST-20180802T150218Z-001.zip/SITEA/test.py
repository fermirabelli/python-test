import xml.etree.ElementTree as ET
import copy

s = """<a>
   <b>
    <c>World</c>
   </b>
 </a>"""

file = ET.fromstring(s)
b = file.find("b")
for c in file.findall(".//c"):
    dupe = copy.deepcopy(c) #copy <c> node
    b.append(dupe) #insert the new node

print(ET.tostring(file))
